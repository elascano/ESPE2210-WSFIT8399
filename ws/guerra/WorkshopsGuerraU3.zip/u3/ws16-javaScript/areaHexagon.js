var a=3;

var p=5;

area=(p*a)/2;
console.log('The area of hexagon is -->' ,area );
