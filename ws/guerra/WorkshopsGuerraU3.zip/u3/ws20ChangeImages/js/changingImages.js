//javascript tp load images
function changeImage1()
{
    document.getElementById("bigPicture").src = "images/img0.jpg";
}

function changeImage2()
{
    document.getElementById("bigPicture").src = "images/img2.jpg";
}

function changeImage3()
{
    document.getElementById("bigPicture").src = "images/img3.jpg";
}

function changeImage4()
{
    document.getElementById("bigPicture").src = "images/img1.jpg";
}

