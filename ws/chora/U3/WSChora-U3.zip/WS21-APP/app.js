function validateUser(){
    var usuario = $('#username').val();
    var password = $('#password').val();
    
}