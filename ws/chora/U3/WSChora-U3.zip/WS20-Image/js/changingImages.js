//javascript tp load images
function changeImage1()
{
    document.getElementById("bigPicture").src = "images/copito1.jpg";
}

function changeImage2()
{
    document.getElementById("bigPicture").src = "images/copito2.jpg";
}

function changeImage3()
{
    document.getElementById("bigPicture").src = "images/copito3.jpg";
}

function changeImage4()
{
    document.getElementById("bigPicture").src = "images/copito4.jpg";
}
