//javascript tp load images
function changeImage1()
{
    document.getElementById("bigPicture").src = "../Imagenes/product1.png";
}

function changeImage2()
{
    document.getElementById("bigPicture").src = "../Imagenes/product2.png";
}

function changeImage3()
{
    document.getElementById("bigPicture").src = "../Imagenes/product3.png";
}

function changeImage4()
{
    document.getElementById("bigPicture").src = "../Imagenes/product4.png";
}

function changeImage5()
{
    document.getElementById("bigPicture").src = "../Imagenes/product5.png";
}

function changeImage6()
{
    document.getElementById("bigPicture").src = "../Imagenes/product6.png";
}

function changeImage7()
{
    document.getElementById("bigPicture").src = "../Imagenes/product7.jpg";
}

function changeImage8()
{
    document.getElementById("bigPicture").src = "../Imagenes/product8.jpg";
}

function changeImage9()
{
    document.getElementById("bigPicture").src = "../Imagenes/product9.jpg";
}