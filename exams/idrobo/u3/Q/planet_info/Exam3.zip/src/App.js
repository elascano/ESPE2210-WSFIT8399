import React from "react";
import PlanetInfo from "./show_planets";

function App() {
  return (
    <div>
      <h1>Star Wars Planets</h1>
      <PlanetInfo />
    </div>
  );
}

export default App;
